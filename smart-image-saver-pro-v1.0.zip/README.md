# Smart Image Saver

Smart Image Saver is a Chrome Extension that allows you to save **any type of image** from the web — even if it's protected using HTML overlays, CSS filters, canvas, or JavaScript tricks.

## 🔥 Features

- Save `<img>` tags, CSS background images, canvas drawings, and even base64 images.
- Bypass right-click protections and overlays automatically.
- "Smart Save" mode: detects the best extraction method.
- Optional license key system to restrict premium features.

## 🧪 Demo

This repository contains a **limited demo version** with detection only.  
To unlock full saving capabilities, please contact the author for a commercial license.

## 🛠 Installation

1. Clone or download this repository.
2. Open `chrome://extensions` in Chrome.
3. Enable "Developer mode".
4. Click "Load unpacked" and select this folder.

## 📦 Files

- `background.js`: handles context menus and downloads.
- `content.js`: image detection and injection logic.
- `popup.html`: extension interface.
- `overlay_detector.js`: smart protection scan.
- `manifest.json`: Chrome Extension manifest.

## 🔐 License

This code is released under a limited demonstration license.  
Please contact the author for a full license or commercial integration.